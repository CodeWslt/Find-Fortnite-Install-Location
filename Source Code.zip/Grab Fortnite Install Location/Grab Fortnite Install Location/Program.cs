﻿using Newtonsoft.Json.Linq;
using System;
using System.IO;

namespace Grab_Fortnite_Install_Location
{
    class Program
    {
        ///This Program Reads Epic Games LauncherInstalled.dat To Find Fortnites Install Location
        ///You Must Own Epic Games Launcher For it To Work Correctly
        ///Program Fully Created By Wslt#1056 Please Credit If Used.
        static void Main(string[] args)
        {
            Findinstall();
            Console.ReadLine();
        }

        public static string GetDirectory()
        {
            ///Finds Epics Program Data Directory
            if (Directory.Exists(@"C:\ProgramData\Epic"))
            {
                return @"C:\ProgramData\Epic";
            }
            if (Directory.Exists(@"D:\ProgramData\Epic"))
            {
                return @"D:\ProgramData\Epic";
            }
            if (Directory.Exists(@"E:\ProgramData\Epic"))
            {
                return @"E:\ProgramData\Epic";
            }
            if (Directory.Exists(@"F:\ProgramData\Epic"))
            {
                return @"F:\ProgramData\Epic";
            }
            return "error"; ///Returns Error If It Can't Find it
        }
        public static void Findinstall()///Reads Epicdata Json And Checks If Its Fortnite Install Path
        {
            string EpicData = GetDirectory();
            if (File.Exists(EpicData + @"\UnrealEngineLauncher\LauncherInstalled.dat"))
            {
                var jsonObject = JObject.Parse(File.ReadAllText(EpicData + @"\UnrealEngineLauncher\LauncherInstalled.dat")); ///Formats The Json
                foreach (var Installs in jsonObject["InstallationList"]) ///Go Throughs Every Json Value
                {
                    if (Directory.Exists(Installs["InstallLocation"] + @"\FortniteGame")) ///Checks If Path Contains The FortniteGame Folder
                    {
                        Console.WriteLine("Found Fortnite Install Location: " + Installs["InstallLocation"] + @"\FortniteGame"); ///Writes Fortnite Install Path To Console
                    }
                }
            }
            else
            {
                Console.WriteLine("Couldent Find LauncherInstalled.dat Make Sure You Have Epic Games Installed!"); ///Writes This Error If It Can't Find The File Called LauncherInstalled.dat
            }
        }
    }
}
